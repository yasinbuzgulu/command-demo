import java.util.LinkedList;
import java.util.Queue;
// baş müzakereci = Invoker

public class ChiefNegotiator {
    private Queue<Question> questionQueue = new LinkedList<>();
    
    // Soru topla
    void collect(Question q) {
        questionQueue.add(q);
    }
    
    // Uygun zamanda müzakerecinin önüne koy
    void presentNextQuestion() {
        Question q = questionQueue.poll();
        if (q != null) {
            q.answer();
        }
    }
    
    // Tüm soruları cevaplat
    void presentAllQuestions() {
        while (!questionQueue.isEmpty()) {
            presentNextQuestion();
        }
    }
}
