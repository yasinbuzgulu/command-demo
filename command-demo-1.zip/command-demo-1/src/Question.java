// Soru = Command
public interface Question {
    void answer(); // müzakerecinin yapacağı şey
}
