// Bir öğrencinin sorusu = ConcreteCommand
public class StudentQuestion implements Question {
    private String questionText;
    private Negotiator negotiator; // Kim cevaplayacak
    
    StudentQuestion(String questionText, Negotiator negotiator) {
        this.questionText = questionText;
        this.negotiator = negotiator;
    }
    
    @Override
    public void answer() {
        negotiator.respondTo(questionText); // müzakerecinin methodunu çağır
    }
}