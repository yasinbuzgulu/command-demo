// Talebeler = Client
public class Classroom {
    public static void main(String[] args) {
        Negotiator hoca = new Negotiator("Ahmet Hoca");
        ChiefNegotiator baskan = new ChiefNegotiator();
        
        // Talebeler soruları
        baskan.collect(new StudentQuestion("90km sonrası sünnet kılıyor muyuz?", hoca));
        baskan.collect(new StudentQuestion("Yemeğe tuzla başlamak sünnet mi?", hoca));
        baskan.collect(new StudentQuestion("Namazda fatiha-ı şerife okumayı unutursak ne yapmak lazım?", hoca));
        
        // Ders sonu baş müzakereci kâğıtları müzakerecinin önüne koyuyor
        System.out.println("--- Ders sonu sorular cevaplanıyor ---");
        baskan.presentAllQuestions();
    }
}