
// Müzakereci = Receiver (asıl işi yapan)
public class Negotiator {
    private String name;
    
    Negotiator(String name) { this.name = name; }
    
    void respondTo(String question) {
        System.out.println(name + " cevaplıyor: " + question);
    }

}